export enum UsersAuthRoutes {
	LOGIN = "login",
	SIGNUP = "signup",
	CURRENT = "current",
}
