const generateRandomBody = require("./dataGenerate");

for (let index = 0; index < 5; index++) {
    console.log(generateRandomBody());
    
}